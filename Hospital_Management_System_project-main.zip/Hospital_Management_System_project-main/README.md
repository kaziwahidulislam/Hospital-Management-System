# Hospital Management System

A Node.js and Express multi-role web application designed to streamline core healthcare operations[cite: 1]. It features secure authentication and dedicated access control for Admins, Doctors, and Patients[cite: 1], alongside streamlined workflows for scheduled appointments and laboratory testing management[cite: 1].

---

## Key Features

- **Role-Based Authentication**: Custom middleware handling access rights for Admins, Doctors, and Patients[cite: 1].
- **Appointment Scheduling**: Workflows for booking and managing patient appointments[cite: 1].
- **Lab Testing Module**: System for recording, ordering, and tracking patient lab tests[cite: 1].
- **Modular Middleware**: Express-based routing and request validation logic[cite: 1].

---

## Tech Stack

- **Server Environment**: Node.js[cite: 1]
- **Web Framework**: Express.js[cite: 1]
- **Templating Engines**: EJS / Handlebars[cite: 1]
- **Development & Testing Tools**: Nodemon, Faker.js, Marked[cite: 1]

---

## Project Structure

```text
Hospital_Management_System/
├── app.js               # Main entry point for the application[cite: 1]
├── database.txt         # Schema definitions or seed configurations[cite: 1]
├── middleware/          # Role authentication and route logic[cite: 1]
│   ├── AdminLogin.js[cite: 1]
│   ├── Appointment.js[cite: 1]
│   ├── Doctor.js[cite: 1]
│   ├── DoctorLogin.js[cite: 1]
│   ├── LabTest.js[cite: 1]
│   └── Patient.js[cite: 1]
└── package.json         # Project dependencies and script configurations[cite: 1]